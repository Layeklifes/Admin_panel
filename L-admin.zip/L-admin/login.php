<?php
// login.php

// Load the JSON file
$jsonFile = 'data.json';
if (!file_exists($jsonFile)) {
    // Handle error if the file does not exist
    $response = array('success' => false, 'message' => 'User data file not found.');
    header('Content-Type: application/json');
    echo json_encode($response);
    exit;
}

$jsonData = file_get_contents($jsonFile);
$users = json_decode($jsonData, true);

// Check if JSON decoding was successful
if ($users === null) {
    // Handle JSON decoding error
    $response = array('success' => false, 'message' => 'Error decoding user data.');
    header('Content-Type: application/json');
    echo json_encode($response);
    exit;
}

// Get the posted data
$input = json_decode(file_get_contents('php://input'), true);
$username = isset($input['username']) ? $input['username'] : '';
$password = isset($input['password']) ? $input['password'] : '';

// Check if username and password are not empty
if (empty($username) || empty($password)) {
    $response = array('success' => false, 'message' => 'Username or password cannot be empty.');
    header('Content-Type: application/json');
    echo json_encode($response);
    exit;
}

// Check if the username and password are valid
foreach ($users as $user) {
    if ($user['username'] === $username && $user['password'] === $password) {
        $response = array('success' => true, 'username' => $username);
        break;
    }
}

// If no valid user was found, set the response to false
if (!isset($response)) {
    $response = array('success' => false, 'message' => 'Invalid username or password.');
}

// Return the response as JSON
header('Content-Type: application/json');
echo json_encode($response);
?>
